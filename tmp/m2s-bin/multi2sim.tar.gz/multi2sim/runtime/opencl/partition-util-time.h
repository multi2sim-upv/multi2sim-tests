#ifndef __PARTITION_UTIL_TIME_H__
#define __PARTITION_UTIL_TIME_H__

long long get_time();

#endif

